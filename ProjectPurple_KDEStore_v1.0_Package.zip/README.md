# Project Purple — KDE Plasma Global Theme (v1.0)
Minimal. Neon. Unmistakably Purple.

## Files
- ProjectPurple_GlobalTheme_v1_KPackage.zip  (install this zip as the theme)
- ProjectPurple_KDEStore_v1.0.zip            (screenshots, banners, promo, feature preview)

## Install (User Scope)
```bash
unzip ProjectPurple_GlobalTheme_v1_KPackage.zip -d ~/.local/share/plasma/look-and-feel/
kbuildsycoca6 --noincremental
lookandfeeltool -a org.projectpurple

# Fedora cursor build (first run only)
sudo dnf install -y xcursorgen
~/.local/share/plasma/look-and-feel/ProjectPurple/contents/cursors/ProjectPurpleCursor/build.sh
```

## Support & Donations
PayPal — jones.lm89@gmail.com

## License
GPL-3.0
