#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
mkdir -p cursors
if ! command -v xcursorgen >/dev/null 2>&1; then
  echo "Missing xcursorgen. Install and re-run (e.g., sudo dnf install -y xcursorgen)."
  exit 1
fi
for n in left_ptr text sb_h_double_arrow sb_v_double_arrow wait; do
  echo "Building $n"
  xcursorgen "src/$n.cfg" "cursors/$n"
done
echo "Done. Select 'ProjectPurpleCursor' in System Settings → Cursors."
