Screenshots & banners for KDE Store — Project Purple v1.0
